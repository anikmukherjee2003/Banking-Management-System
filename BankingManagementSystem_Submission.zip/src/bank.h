#ifndef BANKING_MANAGEMENT_SYSTEM_BANK_H
#define BANKING_MANAGEMENT_SYSTEM_BANK_H

#include <limits.h>
#include <semaphore.h>
#include <stddef.h>
#include <sys/types.h>

#define BANK_MAX_USERS 128
#define BANK_MAX_TRANSACTIONS 4096
#define BANK_MAX_LOANS 512
#define BANK_MAX_FEEDBACK 512
#define BANK_MAX_SESSIONS 128
#define BANK_REQUEST_MAX 8192
#define BANK_RESPONSE_MAX 65536

typedef struct {
    char username[33];
    char salt_hex[33];
    char password_hash[65];
    char role[20];
    int active;
    char name[101];
    char email[161];
    char phone[41];
} BankUser;

typedef struct {
    char username[33];
    char number[16];
    long long balance_paise;
    char status[12];
} BankAccount;

typedef struct {
    char id[20];
    char username[33];
    char type[24];
    long long amount_paise;
    long long balance_after_paise;
    char related_account[16];
    char reference[20];
    long long created_at;
    char memo[241];
} BankTransaction;

typedef struct {
    char id[20];
    char username[33];
    long long amount_paise;
    char purpose[241];
    char status[16];
    char assigned_to[33];
    char reviewed_by[33];
    long long created_at;
    long long reviewed_at;
} BankLoan;

typedef struct {
    char id[20];
    char username[33];
    char message[1001];
    int reviewed;
    long long created_at;
} BankFeedback;

typedef struct {
    char username[33];
    char token[65];
    pid_t worker_pid;
    long long last_seen;
} BankSessionRecord;

typedef struct {
    int next_account;
    int next_transaction;
    int next_loan;
    int next_feedback;
    size_t user_count;
    size_t account_count;
    size_t transaction_count;
    size_t loan_count;
    size_t feedback_count;
    size_t session_count;
    BankUser users[BANK_MAX_USERS];
    BankAccount accounts[BANK_MAX_USERS];
    BankTransaction transactions[BANK_MAX_TRANSACTIONS];
    BankLoan loans[BANK_MAX_LOANS];
    BankFeedback feedback[BANK_MAX_FEEDBACK];
    BankSessionRecord sessions[BANK_MAX_SESSIONS];
} BankState;

typedef struct {
    char data[BANK_RESPONSE_MAX];
    size_t length;
} BankResponse;

typedef struct {
    char data_dir[PATH_MAX];
    char database_path[PATH_MAX];
    char lock_path[PATH_MAX];
    sem_t *database_semaphore;
} BankStore;

typedef struct {
    int authenticated;
    char username[33];
    char token[65];
} BankSession;

int bank_store_init(BankStore *store, const char *data_dir, sem_t *database_semaphore);
void bank_execute(BankStore *store, BankSession *session, const char *request, BankResponse *response);
void bank_close_session(BankStore *store, BankSession *session);

#endif
